import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WebDriverNavigate 
{	
	public static void main(String[] args)
	{
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://www.google.com/in");
		
		driver.navigate().to("http://www.seleniumhq.org/");
		
		driver.navigate().back();
	}
}
