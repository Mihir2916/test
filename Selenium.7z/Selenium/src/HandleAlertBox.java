import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HandleAlertBox
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		//File pathToBinary = new File("C:/Program Files/Mozilla Firefox/firefox.exe");
		//FirefoxProfile firefoxProfile = new FirefoxProfile();
		//FirefoxBinary binary = new FirefoxBinary(pathToBinary);
				
		WebDriver driver = new FirefoxDriver();
		
		String alertMessage; 
		driver.get("file:/D:/MJ/VnV Auto & Man Testing/Selenium/Selenium Installations/Selenium Demos & Lab files/WebDriverDemos/HandleAlertBox.html");
		
		driver.findElement(By.name("btnAlert")).click();
		alertMessage = driver.switchTo().alert().getText();
		
        driver.switchTo().alert().accept();
        System.out.println(alertMessage);
	}

}
