package org.testng;

public @interface Test {

	int priority();

}
