package org.testng;

public @interface Aftertest {

}
