package org.testng;

public @interface AfterClass {

}
