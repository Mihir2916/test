package org.testng;

public class MalFormedURLException extends Exception {

}
