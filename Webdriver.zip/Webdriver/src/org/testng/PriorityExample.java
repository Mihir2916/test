package org.testng;

import org.testng.annotations.Test;

public class PriorityExample {

	@Test(priority=2)
	public void send() 
	{
		System.out.println("After Login first mail can be send");
	}
	
	@Test(priority=1)
	public void Login()
	{
		System.out.println("After Registration user can Login");
	}
	
	@Test(priority=0)
	public void Register()
	{
		System.out.println("User needs to Register");
	}

}
