package org.testng;

public @interface BeforeClass {

}
