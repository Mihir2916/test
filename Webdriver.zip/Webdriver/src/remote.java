


import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class remote {

	WebDriver driver;
	String baseurl,nodeurl;
	@BeforeTest
	public void display() throws MalformedURLException
	{
		baseurl="file:///D:/MJ/VnV Auto & Man Testing/Old Firefox/Selenium/Selenium Installations/Selenium Demos & Lab files/Lesson 5-HTML Pages/Lesson 5-HTML Pages/WorkingWithForms.html";
		nodeurl="http://10.102.57.7:5666/wd/hub";
		new DesiredCapabilities();
		DesiredCapabilities t = DesiredCapabilities.chrome();
		t.setBrowserName("chrome");
		t.setPlatform(Platform.WINDOWS);
		driver= new RemoteWebDriver(new URL (nodeurl),t);
		
	}
	
	@AfterTest
	public void aftertest()
	{
		//driver.close();
	}
	
	@Test
	public void simpletest()
	{
		driver.get(baseurl);
		//Thread.sleep(1000);
		Assert.assertEquals("Email Registration Form", driver.getTitle());
	}

	}


