package webdriver;

import static org.testng.AssertJUnit.assertEquals;
import org.testng.annotations.Test;

public class TestNGExample 
{

	@Test
	public void testcheck() 
	 {
		String str = "Welcome to Heaven";
				assertEquals("Welcome to Heaven",str);
	}

}
