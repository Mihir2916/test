package webdriver;

public class AlertBox 
{

	public static void main(String[] args)
	{
		
	}

}
