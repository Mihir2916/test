package webdriver;


import org.junit.AfterClass;
import org.junit.Test;

public class AlphabeticalOrder {
		
	@Test
		public void b()
		{
			System.out.println("TestMethod1");
		}
		
	@Test
		public void a() 
		{
			System.out.println("TestMethod2");
		}
		
	@AfterClass
		public static void close()
		{
			System.out.println("After");
		}

	}