package webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


@SuppressWarnings("unused")
public class WebDriverWait1 
{
	public static void main(String[] args)
	{
	WebDriver driver = new FirefoxDriver();
	
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver,30);
	
	String baseurl = "file:///D:/MJ/VnV%20Auto%20&%20Man%20Testing/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
	
	driver.get(baseurl);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txtUserName"))).sendKeys("Mihir");
	
	//WebElement t = driver.findElement(By.id("txtUserName"));
	//t.sendKeys("Mihir");
	}
}
