package webdriver;


import org.junit.Test;

public class FIFO {

	@Test
	public void a4b4() 
	{
		System.out.println("I am in Display");
	}

	@Test
	public void a1b1() 
	{
		System.out.println("I am in exit");
	}

	@Test
	public void a5b5() 
	{
		System.out.println("I am nowhere");
	}

}
