package webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Annotation {

	@Before
	public void initialize()
	{
		System.out.println("Before");
	}
	@Test
	public void mytestmethod() 
	{
		System.out.println("Test");
	}
	@After
	public void close()
	{
		System.out.println("After");
	}

}
