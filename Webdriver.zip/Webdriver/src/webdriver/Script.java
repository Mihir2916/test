package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Script
{
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		String sText;
		WebDriver driver = new FirefoxDriver();
		JavascriptExecutor js= (JavascriptExecutor)driver;
		
		js.executeScript("history.go(0)");
		
	driver.get("file:///D:/MJ/VnV%20Auto%20&%20Man%20Testing/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/AlertExample.html");
	sText = js.executeScript("return document.title;").toString();
	System.out.println(sText);
	
	driver.findElement(By.name("txtName")).sendKeys("Mihir");
	WebElement button= driver.findElement(By.name("btnAlert"));
	
//Perform Click on show Alert box button using JavascriptExecutor
	//js.executeScript("arguments[0].click();",button);
	
	js.executeScript("alert('Hello World');");
	}
}

