package webdriver;

import org.openqa.selenium.*;
import org.openqa.selenium.ie.*;

public class Test {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		//String baseurl="file:////D:/WorkingWithForms.html";		
		driver.get("https://talent.capgemini.com/in");
		}
}
