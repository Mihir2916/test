package webdriver;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class WithIgnore 
{
	@BeforeClass
	public static
	void initialize()
	{
		System.out.println("Before Class");
	}
	
	@Before
	public void a()
	{
		System.out.println("Before");
	}
	
	@Test
	public void mytestmethod() 
	{
		System.out.println("Test1");
	}
	
	@Ignore
	@Test
	public void mytest() 
	{
		System.out.println("Test2");
	}
	
	@After
	public void close()
	{
		System.out.println("After");
	}

	@AfterClass
	public static void close1()
	{
		System.out.println("AfterClass");
	}

	
}
