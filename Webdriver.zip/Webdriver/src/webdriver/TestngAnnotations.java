package webdriver;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class TestngAnnotations {

	@Test
	public void test1() 
	{
		System.out.println("Test1");
	}
	
	@Test
	public void test2()
	{
		System.out.println("Test2");
	}
	
	@Test @BeforeMethod
	public void test3()
	{
		System.out.println("Before Method");
	}
	
	@Test @AfterMethod
	public void test4()
	{
		System.out.println("After Method");
		
	}
	
	@BeforeClass
	public void test5()
	{
		System.out.println("Before Class");
	}
	
	@AfterClass
	public void test6()
	{
		System.out.println("AfterClass");
	}

	@Test @BeforeTest
		public void test7()
		{
			System.out.println("Before Test");
		}	
	
	@AfterClass
	public void test8()
	{
		System.out.println("After Test");
	}
	
	@Test @BeforeSuite
	public void test9()
	{
		System.out.println("Before Suite");
	}
	
	@Test @AfterSuite
	public void test10()
	{
		System.out.println("After Suite");
	}
}
