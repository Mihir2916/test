package webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Chrome {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","D:/MJ/VnV Auto & Man Testing/New folder (10)/chromedriver_win32/chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		//String baseurl="file:////D:/WorkingWithForms.html";
		String baseurl="https://talent.capgemini.com/in";
		
		driver.get(baseurl);
		
	}

}
